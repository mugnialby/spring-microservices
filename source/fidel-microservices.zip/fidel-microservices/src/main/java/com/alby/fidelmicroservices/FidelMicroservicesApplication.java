package com.alby.fidelmicroservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FidelMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FidelMicroservicesApplication.class, args);
	}

}
